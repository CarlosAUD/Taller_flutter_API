import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:cached_network_image/cached_network_image.dart';

class AnimeInfoPage extends StatefulWidget {
  @override
  _AnimeInfoPageState createState() => _AnimeInfoPageState();
}

class _AnimeInfoPageState extends State<AnimeInfoPage> {
  Map<String, dynamic> animeData = {};  // Para almacenar la información del anime
  bool isLoading = false;  // Para mostrar el cargador mientras esperamos la respuesta
  TextEditingController searchController = TextEditingController();  // Controlador del campo de texto

  // Función para realizar la búsqueda del anime
  Future<void> searchAnime(String animeName) async {
    setState(() {
      isLoading = true;  // Iniciar el cargador
      animeData = {};  // Limpiar datos anteriores
    });

    // Realizamos la solicitud HTTP
    final response = await http.get(
      Uri.parse('https://api.jikan.moe/v4/anime?q=$animeName'),
    );

    if (response.statusCode == 200) {
      // Si la respuesta es exitosa, parseamos el JSON
      setState(() {
        animeData = json.decode(response.body)['data'][0];  // Tomamos el primer resultado
        isLoading = false;
      });
    } else {
      // Si la respuesta no es exitosa, mostramos un mensaje
      setState(() {
        isLoading = false;
        animeData = {};  // Limpiar datos
      });
      // Opcional: Mostrar un mensaje de error
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('No se pudo encontrar el anime')),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Buscar Anime'),
      ),
      body: Center(
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              // Campo de texto para ingresar el nombre del anime
              TextField(
                controller: searchController,
                decoration: InputDecoration(
                  labelText: 'Buscar Anime',
                  border: OutlineInputBorder(),
                  suffixIcon: IconButton(
                    icon: Icon(Icons.search),
                    onPressed: () {
                      String animeName = searchController.text.trim();
                      if (animeName.isNotEmpty) {
                        searchAnime(animeName);
                      }
                    },
                  ),
                ),
                onSubmitted: (value) {
                  if (value.isNotEmpty) {
                    searchAnime(value);
                  }
                },
              ),
              SizedBox(height: 20),
              // Muestra el cargador mientras esperamos la respuesta
              isLoading
                  ? CircularProgressIndicator()
                  : animeData.isEmpty
                      ? Text('No se ha encontrado ningún anime')
                      : SingleChildScrollView(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              CachedNetworkImage(
                                imageUrl: animeData['images']['jpg']['large_image_url'],
                                placeholder: (context, url) => CircularProgressIndicator(),
                                errorWidget: (context, url, error) => Icon(Icons.error),
                              ),
                              SizedBox(height: 10),
                              Padding(
                                padding: const EdgeInsets.all(8.0),
                                child: Text(
                                  animeData['title'] ?? 'No Title',
                                  style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
                                ),
                              ),
                              Padding(
                                padding: const EdgeInsets.all(8.0),
                                child: Text(
                                  animeData['synopsis'] ?? 'No Description',
                                  style: TextStyle(fontSize: 16),
                                ),
                              ),
                            ],
                          ),
                        ),
            ],
          ),
        ),
      ),
    );
  }
}

void main() {
  runApp(MaterialApp(
    home: AnimeInfoPage(),
  ));
}
