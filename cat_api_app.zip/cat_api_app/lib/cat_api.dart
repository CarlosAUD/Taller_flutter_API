import 'dart:convert';
import 'package:http/http.dart' as http;

class CatApi {
  static const String _baseUrl = 'https://api.thecatapi.com/v1/images/search';

  // Método para obtener una imagen aleatoria de un gato
  static Future<String> fetchCatImage() async {
    final response = await http.get(Uri.parse(_baseUrl));

    if (response.statusCode == 200) {
      final List<dynamic> data = json.decode(response.body);
      return data[0]['url']; // Regresa la URL de la imagen del gato
    } else {
      throw Exception('Failed to load cat image');
    }
  }
}
